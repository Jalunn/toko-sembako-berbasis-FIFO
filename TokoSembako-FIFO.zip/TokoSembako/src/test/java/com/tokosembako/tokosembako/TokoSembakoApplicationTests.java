package com.tokosembako.tokosembako;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TokoSembakoApplicationTests {

	@Test
	void contextLoads() {
	}

}
