package com.tokosembako.tokosembako.controller;

import com.tokosembako.tokosembako.entity.Barang;
import com.tokosembako.tokosembako.service.BarangService;
import com.tokosembako.tokosembako.service.KategoriService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/barang")
public class BarangController {

    private final BarangService barangService;
    private final KategoriService kategoriService;

    public BarangController(BarangService barangService, KategoriService kategoriService) {
        this.barangService = barangService;
        this.kategoriService = kategoriService;
    }

    @GetMapping
    public String index(Model model) {
        model.addAttribute("barangList", barangService.getAllBarang());
        model.addAttribute("kategoriList", kategoriService.getAllKategori());
        model.addAttribute("barang", new Barang());

        return "barang";
    }

    @PostMapping("/simpan")
    public String simpan(@ModelAttribute Barang barang) {
        barangService.saveBarang(barang);

        return "redirect:/barang";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id, Model model) {
        model.addAttribute("barang", barangService.getBarangById(id));
        model.addAttribute("barangList", barangService.getAllBarang());
        model.addAttribute("kategoriList", kategoriService.getAllKategori());

        return "barang";
    }

    @GetMapping("/hapus/{id}")
    public String hapus(@PathVariable Long id) {
        barangService.deleteBarang(id);

        return "redirect:/barang";
    }
}
