package com.tokosembako.tokosembako.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "penjualan")
public class Penjualan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "barang_id", nullable = false)
    private Barang barang;

    @Column(nullable = false)
    private LocalDateTime tanggal;

    @Column(nullable = false)
    private Integer jumlahJual;

    @Column(nullable = false)
    private Double hargaJualSaatItu;

    @Column(nullable = false)
    private Double totalJual;

    // Hasil perhitungan FIFO: total harga pokok penjualan dari batch-batch yang terpakai
    @Column(nullable = false)
    private Double totalHpp;

    @OneToMany(mappedBy = "penjualan", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PenjualanDetail> detailList = new ArrayList<>();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Barang getBarang() { return barang; }
    public void setBarang(Barang barang) { this.barang = barang; }

    public LocalDateTime getTanggal() { return tanggal; }
    public void setTanggal(LocalDateTime tanggal) { this.tanggal = tanggal; }

    public Integer getJumlahJual() { return jumlahJual; }
    public void setJumlahJual(Integer jumlahJual) { this.jumlahJual = jumlahJual; }

    public Double getHargaJualSaatItu() { return hargaJualSaatItu; }
    public void setHargaJualSaatItu(Double hargaJualSaatItu) { this.hargaJualSaatItu = hargaJualSaatItu; }

    public Double getTotalJual() { return totalJual; }
    public void setTotalJual(Double totalJual) { this.totalJual = totalJual; }

    public Double getTotalHpp() { return totalHpp; }
    public void setTotalHpp(Double totalHpp) { this.totalHpp = totalHpp; }

    public Double getLabaKotor() {
        if (totalJual == null || totalHpp == null) return null;
        return totalJual - totalHpp;
    }

    public List<PenjualanDetail> getDetailList() { return detailList; }
    public void setDetailList(List<PenjualanDetail> detailList) { this.detailList = detailList; }
}
