package com.tokosembako.tokosembako;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TokoSembakoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TokoSembakoApplication.class, args);
	}

}