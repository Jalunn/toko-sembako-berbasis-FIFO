
package com.tokosembako.tokosembako.repository;

import com.tokosembako.tokosembako.entity.Barang;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BarangRepository extends JpaRepository<Barang, Long> {
}