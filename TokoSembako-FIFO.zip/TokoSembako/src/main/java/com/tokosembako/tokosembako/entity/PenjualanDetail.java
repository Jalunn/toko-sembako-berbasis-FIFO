package com.tokosembako.tokosembako.entity;

import jakarta.persistence.*;

// Mencatat batch (StokMasuk) mana saja yang "termakan" oleh satu transaksi penjualan.
// Inilah jejak/bukti bahwa pengurangan stok memakai urutan FIFO, bukan sekadar angka total.
@Entity
@Table(name = "penjualan_detail")
public class PenjualanDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "penjualan_id", nullable = false)
    private Penjualan penjualan;

    @ManyToOne
    @JoinColumn(name = "stok_masuk_id", nullable = false)
    private StokMasuk stokMasuk;

    @Column(nullable = false)
    private Integer jumlahDipakai;

    // Harga beli batch ini pada saat dipakai (disimpan terpisah agar riwayat akurat
    // walau suatu saat data StokMasuk berubah)
    @Column(nullable = false)
    private Double hargaBeliSaatItu;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Penjualan getPenjualan() { return penjualan; }
    public void setPenjualan(Penjualan penjualan) { this.penjualan = penjualan; }

    public StokMasuk getStokMasuk() { return stokMasuk; }
    public void setStokMasuk(StokMasuk stokMasuk) { this.stokMasuk = stokMasuk; }

    public Integer getJumlahDipakai() { return jumlahDipakai; }
    public void setJumlahDipakai(Integer jumlahDipakai) { this.jumlahDipakai = jumlahDipakai; }

    public Double getHargaBeliSaatItu() { return hargaBeliSaatItu; }
    public void setHargaBeliSaatItu(Double hargaBeliSaatItu) { this.hargaBeliSaatItu = hargaBeliSaatItu; }
}
