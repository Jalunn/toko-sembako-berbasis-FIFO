package com.tokosembako.tokosembako.service;

import com.tokosembako.tokosembako.entity.Kategori;
import com.tokosembako.tokosembako.repository.KategoriRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class KategoriService {

    private final KategoriRepository kategoriRepository;

    public KategoriService(KategoriRepository kategoriRepository) {
        this.kategoriRepository = kategoriRepository;
    }

    public List<Kategori> getAllKategori() {
        return kategoriRepository.findAll();
    }

    public Kategori getKategoriById(Long id) {
        return kategoriRepository.findById(id).orElse(null);
    }

    public void saveKategori(Kategori kategori) {
        kategoriRepository.save(kategori);
    }

    public void deleteKategori(Long id) {
        kategoriRepository.deleteById(id);
    }
}