package com.tokosembako.tokosembako.controller;

import com.tokosembako.tokosembako.service.BarangService;
import com.tokosembako.tokosembako.service.PenjualanService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;

@Controller
@RequestMapping("/penjualan")
public class PenjualanController {

    private final PenjualanService penjualanService;
    private final BarangService barangService;

    public PenjualanController(PenjualanService penjualanService, BarangService barangService) {
        this.penjualanService = penjualanService;
        this.barangService = barangService;
    }

    @GetMapping
    public String index(Model model) {
        model.addAttribute("barangList", barangService.getAllBarang());
        model.addAttribute("riwayatPenjualan", penjualanService.getRiwayatPenjualan());
        return "penjualan";
    }

    @PostMapping("/simpan")
    public String simpan(@RequestParam Long barangId,
                          @RequestParam Integer jumlah,
                          @RequestParam Double hargaJual,
                          RedirectAttributes redirectAttributes) {
        try {
            penjualanService.prosesPenjualan(barangId, jumlah, hargaJual, LocalDateTime.now());
            redirectAttributes.addFlashAttribute("sukses",
                    "Penjualan berhasil dicatat. Stok dikurangi memakai FIFO (batch tertua duluan).");
        } catch (IllegalStateException | IllegalArgumentException e) {
            // Termasuk kasus stok tidak cukup -> pesan ditampilkan ke user, bukan error mentah
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/penjualan";
    }
}
