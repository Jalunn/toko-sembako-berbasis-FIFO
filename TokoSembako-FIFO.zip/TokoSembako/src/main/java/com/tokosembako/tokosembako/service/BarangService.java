package com.tokosembako.tokosembako.service;

import com.tokosembako.tokosembako.entity.Barang;
import com.tokosembako.tokosembako.repository.BarangRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BarangService {

    private final BarangRepository barangRepository;

    public BarangService(BarangRepository barangRepository) {
        this.barangRepository = barangRepository;
    }

    public List<Barang> getAllBarang() {
        return barangRepository.findAll();
    }

    public Barang getBarangById(Long id) {
        return barangRepository.findById(id).orElse(null);
    }

    public void saveBarang(Barang barang) {
        barangRepository.save(barang);
    }

    public void deleteBarang(Long id) {
        barangRepository.deleteById(id);
    }
}
