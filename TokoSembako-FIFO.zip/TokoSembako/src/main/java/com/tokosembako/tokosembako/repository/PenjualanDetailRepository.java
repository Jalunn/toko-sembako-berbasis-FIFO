package com.tokosembako.tokosembako.repository;

import com.tokosembako.tokosembako.entity.Penjualan;
import com.tokosembako.tokosembako.entity.PenjualanDetail;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PenjualanDetailRepository extends JpaRepository<PenjualanDetail, Long> {
    List<PenjualanDetail> findByPenjualan(Penjualan penjualan);
}
