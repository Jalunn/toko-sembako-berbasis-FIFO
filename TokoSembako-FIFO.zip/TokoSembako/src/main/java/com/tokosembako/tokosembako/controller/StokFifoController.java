package com.tokosembako.tokosembako.controller;

import com.tokosembako.tokosembako.entity.Barang;
import com.tokosembako.tokosembako.service.BarangService;
import com.tokosembako.tokosembako.service.StokService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/stok-fifo")
public class StokFifoController {

    private final BarangService barangService;
    private final StokService stokService;

    public StokFifoController(BarangService barangService, StokService stokService) {
        this.barangService = barangService;
        this.stokService = stokService;
    }

    // Daftar barang -> pilih salah satu untuk lihat rincian batch FIFO-nya
    @GetMapping
    public String index(Model model) {
        model.addAttribute("barangList", barangService.getAllBarang());
        return "stok-fifo";
    }

    // Kartu stok per barang: rincian tiap batch, sisa stok, dan urutan pemakaian FIFO
    @GetMapping("/{barangId}")
    public String detail(@PathVariable Long barangId, Model model) {
        Barang barang = barangService.getBarangById(barangId);
        model.addAttribute("barangList", barangService.getAllBarang());
        model.addAttribute("barangDipilih", barang);
        if (barang != null) {
            model.addAttribute("kartuStok", stokService.getKartuStok(barang));
        }
        return "stok-fifo";
    }
}
