package com.tokosembako.tokosembako.controller;

import com.tokosembako.tokosembako.entity.Barang;
import com.tokosembako.tokosembako.service.BarangService;
import com.tokosembako.tokosembako.service.StokService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;

@Controller
@RequestMapping("/pembelian")
public class PembelianController {

    private final StokService stokService;
    private final BarangService barangService;

    public PembelianController(StokService stokService, BarangService barangService) {
        this.stokService = stokService;
        this.barangService = barangService;
    }

    @GetMapping
    public String index(Model model) {
        model.addAttribute("barangList", barangService.getAllBarang());
        model.addAttribute("riwayatStokMasuk", stokService.getRiwayatStokMasuk());
        return "pembelian";
    }

    @PostMapping("/simpan")
    public String simpan(@RequestParam Long barangId,
                          @RequestParam Integer jumlah,
                          @RequestParam Double hargaBeli,
                          RedirectAttributes redirectAttributes) {
        try {
            Barang barang = barangService.getBarangById(barangId);
            if (barang == null) {
                redirectAttributes.addFlashAttribute("error", "Barang tidak ditemukan");
                return "redirect:/pembelian";
            }
            stokService.tambahStokMasuk(barang, jumlah, hargaBeli, LocalDateTime.now());
            redirectAttributes.addFlashAttribute("sukses", "Stok masuk berhasil dicatat (batch baru untuk FIFO)");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/pembelian";
    }
}
