package com.tokosembako.tokosembako.service;

import com.tokosembako.tokosembako.dto.PemakaianBatch;
import com.tokosembako.tokosembako.entity.Barang;
import com.tokosembako.tokosembako.entity.Penjualan;
import com.tokosembako.tokosembako.entity.PenjualanDetail;
import com.tokosembako.tokosembako.repository.BarangRepository;
import com.tokosembako.tokosembako.repository.PenjualanDetailRepository;
import com.tokosembako.tokosembako.repository.PenjualanRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class PenjualanService {

    private final PenjualanRepository penjualanRepository;
    private final PenjualanDetailRepository penjualanDetailRepository;
    private final BarangRepository barangRepository;
    private final StokService stokService;

    public PenjualanService(PenjualanRepository penjualanRepository,
                             PenjualanDetailRepository penjualanDetailRepository,
                             BarangRepository barangRepository,
                             StokService stokService) {
        this.penjualanRepository = penjualanRepository;
        this.penjualanDetailRepository = penjualanDetailRepository;
        this.barangRepository = barangRepository;
        this.stokService = stokService;
    }

    /**
     * Memproses satu transaksi penjualan:
     * 1) kurangi stok memakai FIFO (StokService)
     * 2) hitung HPP dari batch-batch yang terpakai (bisa campur beberapa harga beli)
     * 3) simpan header Penjualan + detail batch yang terpakai sebagai jejak audit
     */
    @Transactional
    public Penjualan prosesPenjualan(Long barangId, Integer jumlahJual, Double hargaJualSaatItu, LocalDateTime tanggal) {
        Barang barang = barangRepository.findById(barangId)
                .orElseThrow(() -> new IllegalArgumentException("Barang tidak ditemukan"));

        List<PemakaianBatch> pemakaian = stokService.kurangiStokFIFO(barang, jumlahJual);

        double totalHpp = pemakaian.stream()
                .mapToDouble(p -> p.getJumlahDipakai() * p.getHargaBeliSaatItu())
                .sum();

        Penjualan penjualan = new Penjualan();
        penjualan.setBarang(barang);
        penjualan.setTanggal(tanggal);
        penjualan.setJumlahJual(jumlahJual);
        penjualan.setHargaJualSaatItu(hargaJualSaatItu);
        penjualan.setTotalJual(jumlahJual * hargaJualSaatItu);
        penjualan.setTotalHpp(totalHpp);
        penjualanRepository.save(penjualan);

        for (PemakaianBatch p : pemakaian) {
            PenjualanDetail detail = new PenjualanDetail();
            detail.setPenjualan(penjualan);
            detail.setStokMasuk(p.getBatch());
            detail.setJumlahDipakai(p.getJumlahDipakai());
            detail.setHargaBeliSaatItu(p.getHargaBeliSaatItu());
            penjualanDetailRepository.save(detail);
        }

        return penjualan;
    }

    public List<Penjualan> getRiwayatPenjualan() {
        return penjualanRepository.findAllByOrderByTanggalDesc();
    }
}
