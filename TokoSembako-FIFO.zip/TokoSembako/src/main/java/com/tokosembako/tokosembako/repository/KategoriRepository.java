package com.tokosembako.tokosembako.repository;

import com.tokosembako.tokosembako.entity.Kategori;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KategoriRepository extends JpaRepository<Kategori, Long> {
}