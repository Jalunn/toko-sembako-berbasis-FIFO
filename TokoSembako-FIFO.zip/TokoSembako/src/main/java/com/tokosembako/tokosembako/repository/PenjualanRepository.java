package com.tokosembako.tokosembako.repository;

import com.tokosembako.tokosembako.entity.Penjualan;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PenjualanRepository extends JpaRepository<Penjualan, Long> {
    List<Penjualan> findAllByOrderByTanggalDesc();
}
