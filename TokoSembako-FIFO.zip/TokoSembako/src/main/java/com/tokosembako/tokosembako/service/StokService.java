package com.tokosembako.tokosembako.service;

import com.tokosembako.tokosembako.dto.PemakaianBatch;
import com.tokosembako.tokosembako.entity.Barang;
import com.tokosembako.tokosembako.entity.StokMasuk;
import com.tokosembako.tokosembako.repository.BarangRepository;
import com.tokosembako.tokosembako.repository.StokMasukRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class StokService {

    private final StokMasukRepository stokMasukRepository;
    private final BarangRepository barangRepository;

    public StokService(StokMasukRepository stokMasukRepository, BarangRepository barangRepository) {
        this.stokMasukRepository = stokMasukRepository;
        this.barangRepository = barangRepository;
    }

    /**
     * Mencatat barang masuk sebagai SATU BATCH baru (mis. dari pembelian ke supplier).
     * Setiap batch punya tanggal masuk & harga beli sendiri — inilah yang nanti
     * dipakai FIFO untuk menentukan batch mana yang keluar duluan.
     */
    @Transactional
    public StokMasuk tambahStokMasuk(Barang barang, Integer jumlah, Double hargaBeli, LocalDateTime tanggal) {
        if (jumlah == null || jumlah <= 0) {
            throw new IllegalArgumentException("Jumlah barang masuk harus lebih dari 0");
        }

        StokMasuk batch = new StokMasuk(barang, tanggal, jumlah, hargaBeli);
        stokMasukRepository.save(batch);

        // stok di Barang adalah TOTAL cache (sum seluruh sisaStok batch),
        // supaya halaman daftar barang tidak perlu query batch tiap kali tampil
        int stokSekarang = barang.getStok() == null ? 0 : barang.getStok();
        barang.setStok(stokSekarang + jumlah);
        barangRepository.save(barang);

        return batch;
    }

    /**
     * INTI ALGORITMA FIFO.
     * Mengurangi stok sejumlah `jumlahKeluar` dengan mengambil dari batch TERTUA lebih dulu,
     * baru lanjut ke batch berikutnya kalau batch tertua sudah habis.
     * Mengembalikan rincian batch mana saja yang terpakai (dipakai untuk hitung HPP).
     */
    @Transactional
    public List<PemakaianBatch> kurangiStokFIFO(Barang barang, Integer jumlahKeluar) {
        if (jumlahKeluar == null || jumlahKeluar <= 0) {
            throw new IllegalArgumentException("Jumlah keluar harus lebih dari 0");
        }

        List<StokMasuk> batchTersedia = stokMasukRepository
                .findByBarangAndSisaStokGreaterThanOrderByTanggalMasukAsc(barang, 0);

        int totalTersedia = batchTersedia.stream()
                .mapToInt(StokMasuk::getSisaStok)
                .sum();

        if (totalTersedia < jumlahKeluar) {
            throw new IllegalStateException(
                    "Stok " + barang.getNamaBarang() + " tidak mencukupi. "
                            + "Tersedia: " + totalTersedia + ", diminta: " + jumlahKeluar);
        }

        List<PemakaianBatch> hasilPemakaian = new ArrayList<>();
        int sisaDibutuhkan = jumlahKeluar;

        for (StokMasuk batch : batchTersedia) {
            if (sisaDibutuhkan <= 0) {
                break;
            }

            int ambilDariBatchIni = Math.min(batch.getSisaStok(), sisaDibutuhkan);

            batch.setSisaStok(batch.getSisaStok() - ambilDariBatchIni);
            stokMasukRepository.save(batch);

            hasilPemakaian.add(new PemakaianBatch(batch, ambilDariBatchIni, batch.getHargaBeli()));

            sisaDibutuhkan -= ambilDariBatchIni;
        }

        int stokSekarang = barang.getStok() == null ? 0 : barang.getStok();
        barang.setStok(stokSekarang - jumlahKeluar);
        barangRepository.save(barang);

        return hasilPemakaian;
    }

    /** Kartu stok: riwayat semua batch suatu barang, dari yang paling lama masuk. */
    public List<StokMasuk> getKartuStok(Barang barang) {
        return stokMasukRepository.findByBarangOrderByTanggalMasukAsc(barang);
    }

    public List<StokMasuk> getRiwayatStokMasuk() {
        return stokMasukRepository.findAllByOrderByTanggalMasukDesc();
    }
}
