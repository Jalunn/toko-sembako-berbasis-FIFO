package com.tokosembako.tokosembako.controller;

import com.tokosembako.tokosembako.entity.Kategori;
import com.tokosembako.tokosembako.service.KategoriService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/kategori")
public class KategoriController {

    private final KategoriService kategoriService;

    public KategoriController(KategoriService kategoriService) {
        this.kategoriService = kategoriService;
    }

    @GetMapping
    public String index(Model model) {
        model.addAttribute("kategoriList", kategoriService.getAllKategori());
        model.addAttribute("kategori", new Kategori());

        return "kategori";
    }

    @PostMapping("/simpan")
    public String simpan(@ModelAttribute Kategori kategori) {
        kategoriService.saveKategori(kategori);

        return "redirect:/kategori";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id, Model model) {
        model.addAttribute("kategori", kategoriService.getKategoriById(id));
        model.addAttribute("kategoriList", kategoriService.getAllKategori());

        return "kategori";
    }

    @GetMapping("/hapus/{id}")
    public String hapus(@PathVariable Long id) {
        kategoriService.deleteKategori(id);

        return "redirect:/kategori";
    }
}