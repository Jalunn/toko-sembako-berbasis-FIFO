package com.tokosembako.tokosembako.dto;

import com.tokosembako.tokosembako.entity.StokMasuk;

// Objek bantu (bukan entity) untuk membawa hasil perhitungan FIFO
// dari StokService ke PenjualanService: batch mana dipakai, berapa banyak, harga beli berapa.
public class PemakaianBatch {

    private final StokMasuk batch;
    private final Integer jumlahDipakai;
    private final Double hargaBeliSaatItu;

    public PemakaianBatch(StokMasuk batch, Integer jumlahDipakai, Double hargaBeliSaatItu) {
        this.batch = batch;
        this.jumlahDipakai = jumlahDipakai;
        this.hargaBeliSaatItu = hargaBeliSaatItu;
    }

    public StokMasuk getBatch() { return batch; }
    public Integer getJumlahDipakai() { return jumlahDipakai; }
    public Double getHargaBeliSaatItu() { return hargaBeliSaatItu; }
}
