package com.tokosembako.tokosembako.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "stok_masuk")
public class StokMasuk {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "barang_id", nullable = false)
    private Barang barang;

    @Column(nullable = false)
    private LocalDateTime tanggalMasuk;

    @Column(nullable = false)
    private Integer jumlahMasuk;

    // sisaStok = jumlah dari batch ini yang belum terpakai (dasar perhitungan FIFO)
    @Column(nullable = false)
    private Integer sisaStok;

    @Column(nullable = false)
    private Double hargaBeli;

    public StokMasuk() {
    }

    public StokMasuk(Barang barang, LocalDateTime tanggalMasuk, Integer jumlahMasuk, Double hargaBeli) {
        this.barang = barang;
        this.tanggalMasuk = tanggalMasuk;
        this.jumlahMasuk = jumlahMasuk;
        this.sisaStok = jumlahMasuk;
        this.hargaBeli = hargaBeli;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Barang getBarang() { return barang; }
    public void setBarang(Barang barang) { this.barang = barang; }

    public LocalDateTime getTanggalMasuk() { return tanggalMasuk; }
    public void setTanggalMasuk(LocalDateTime tanggalMasuk) { this.tanggalMasuk = tanggalMasuk; }

    public Integer getJumlahMasuk() { return jumlahMasuk; }
    public void setJumlahMasuk(Integer jumlahMasuk) { this.jumlahMasuk = jumlahMasuk; }

    public Integer getSisaStok() { return sisaStok; }
    public void setSisaStok(Integer sisaStok) { this.sisaStok = sisaStok; }

    public Double getHargaBeli() { return hargaBeli; }
    public void setHargaBeli(Double hargaBeli) { this.hargaBeli = hargaBeli; }
}
