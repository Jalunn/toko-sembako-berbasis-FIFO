package com.tokosembako.tokosembako.repository;

import com.tokosembako.tokosembako.entity.Barang;
import com.tokosembako.tokosembako.entity.StokMasuk;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StokMasukRepository extends JpaRepository<StokMasuk, Long> {

    // Ambil batch yang MASIH ADA sisanya, diurutkan dari yang PALING LAMA masuk.
    // Urutan inilah inti algoritma FIFO: batch terlama harus habis duluan.
    List<StokMasuk> findByBarangAndSisaStokGreaterThanOrderByTanggalMasukAsc(Barang barang, Integer sisaStok);

    // Untuk tampilan kartu stok (riwayat semua batch suatu barang)
    List<StokMasuk> findByBarangOrderByTanggalMasukAsc(Barang barang);

    List<StokMasuk> findAllByOrderByTanggalMasukDesc();
}
