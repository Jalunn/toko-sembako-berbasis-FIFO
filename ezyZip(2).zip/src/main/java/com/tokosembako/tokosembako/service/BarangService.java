package com.tokosembako.tokosembako.service;

import com.tokosembako.tokosembako.entity.Barang;
import com.tokosembako.tokosembako.repository.BarangRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BarangService {

    private final BarangRepository barangRepository;

    public BarangService(BarangRepository barangRepository) {
        this.barangRepository = barangRepository;
    }

    public List<Barang> getAllBarang() {
        return barangRepository.findAll();
    }

    public Barang getBarangById(Long id) {
        return barangRepository.findById(id).orElse(null);
    }

    public void saveBarang(Barang barang) {
        barangRepository.save(barang);
    }

    public void tambahStok(Long barangId, Integer jumlah) {

        Barang barang = getBarangById(barangId);

        if (barang == null) {
            throw new RuntimeException("Barang tidak ditemukan");
        }

        int stokLama = barang.getStok() == null ? 0 : barang.getStok();

        barang.setStok(stokLama + jumlah);

        barangRepository.save(barang);
    }

    public void kurangiStok(Long barangId, Integer jumlah) {

        Barang barang = getBarangById(barangId);

        if (barang == null) {
            throw new RuntimeException("Barang tidak ditemukan");
        }

        int stokSekarang = barang.getStok() == null ? 0 : barang.getStok();

        if (stokSekarang < jumlah) {
            throw new RuntimeException("Stok tidak mencukupi");
        }

        barang.setStok(stokSekarang - jumlah);

        barangRepository.save(barang);
    }

    public void deleteBarang(Long id) {
        barangRepository.deleteById(id);
    }
}