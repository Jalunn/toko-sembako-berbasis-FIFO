package com.tokosembako.tokosembako.service;

import com.tokosembako.tokosembako.entity.StokMasuk;
import com.tokosembako.tokosembako.repository.StokMasukRepository;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StokMasukService {

    private final StokMasukRepository repository;

    public StokMasukService(StokMasukRepository repository) {
        this.repository = repository;
    }

    public List<StokMasuk> findAll() {
        return repository.findAll();
    }

    public StokMasuk findById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public StokMasuk save(StokMasuk stokMasuk) {
        return repository.save(stokMasuk);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}