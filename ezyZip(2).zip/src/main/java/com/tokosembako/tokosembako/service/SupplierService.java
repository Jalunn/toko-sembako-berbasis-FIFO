package com.tokosembako.tokosembako.service;

import com.tokosembako.tokosembako.entity.Supplier;
import com.tokosembako.tokosembako.repository.SupplierRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupplierService {

    private final SupplierRepository supplierRepository;

    public SupplierService(SupplierRepository supplierRepository) {
        this.supplierRepository = supplierRepository;
    }

    // Mengambil semua supplier
    public List<Supplier> getAllSupplier() {
        return supplierRepository.findAll();
    }

    // Mengambil supplier berdasarkan ID
    public Supplier getSupplierById(Long id) {
        return supplierRepository.findById(id).orElse(null);
    }

    // Menyimpan atau mengupdate supplier
    public void saveSupplier(Supplier supplier) {
        supplierRepository.save(supplier);
    }

    // Menghapus supplier
    public void deleteSupplier(Long id) {
        supplierRepository.deleteById(id);
    }
}