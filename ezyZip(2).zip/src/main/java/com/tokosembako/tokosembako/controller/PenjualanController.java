package com.tokosembako.tokosembako.controller;

import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;

import com.tokosembako.tokosembako.entity.Barang;
import com.tokosembako.tokosembako.entity.DetailPenjualan;
import com.tokosembako.tokosembako.entity.Penjualan;
import com.tokosembako.tokosembako.repository.PenjualanRepository;
import com.tokosembako.tokosembako.service.BarangService;

import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/penjualan")
public class PenjualanController {

    private final PenjualanRepository penjualanRepository;
    private final BarangService barangService;
    private final ObjectMapper objectMapper;

    public PenjualanController(
            PenjualanRepository penjualanRepository,
            BarangService barangService,
            ObjectMapper objectMapper) {

        this.penjualanRepository = penjualanRepository;
        this.barangService = barangService;
        this.objectMapper = objectMapper;
    }

    // ==========================================
    // DAFTAR PENJUALAN
    // ==========================================

    @GetMapping
    public String index(Model model) {

        model.addAttribute(
                "penjualan",
                penjualanRepository.findAll()
        );

        return "penjualan/index";
    }


    // ==========================================
    // FORM TAMBAH PENJUALAN
    // ==========================================

    @GetMapping("/tambah")
    public String tambah(Model model) {

        Penjualan penjualan = new Penjualan();

        penjualan.setTanggal(
                LocalDateTime.now()
        );

        penjualan.setTotal(0.0);

        model.addAttribute(
                "penjualan",
                penjualan
        );

        model.addAttribute(
                "barangList",
                barangService.getAllBarang()
        );

        return "penjualan/tambah";
    }


    // ==========================================
    // SIMPAN TRANSAKSI MULTI BARANG
    // ==========================================

    @PostMapping("/simpan")
    @Transactional
    public String simpan(

            @RequestParam("tanggal")
            String tanggal,

            @RequestParam("items")
            String itemsJson) {

        try {

            // ==========================================
            // 1. BACA DATA BARANG DARI JSON
            // ==========================================

            List<Map<String, Object>> items =
                    objectMapper.readValue(
                            itemsJson,
                            new TypeReference<List<Map<String, Object>>>() {
                            }
                    );

            if (items == null || items.isEmpty()) {

                throw new RuntimeException(
                        "Belum ada barang dalam transaksi"
                );
            }


            // ==========================================
            // 2. BUAT TRANSAKSI PENJUALAN
            // ==========================================

            Penjualan penjualan =
                    new Penjualan();

            if (tanggal != null &&
                    !tanggal.isEmpty()) {

                penjualan.setTanggal(
                        LocalDateTime.parse(tanggal)
                );

            } else {

                penjualan.setTanggal(
                        LocalDateTime.now()
                );
            }


            double total = 0.0;


            // ==========================================
            // 3. VALIDASI SEMUA BARANG
            // ==========================================

            for (Map<String, Object> item : items) {

                Long barangId =
                        Long.valueOf(
                                item.get("barangId")
                                        .toString()
                        );

                Integer jumlah =
                        Integer.valueOf(
                                item.get("jumlah")
                                        .toString()
                        );

                Double harga =
                        Double.valueOf(
                                item.get("harga")
                                        .toString()
                        );


                Barang barang =
                        barangService.getBarangById(
                                barangId
                        );


                if (barang == null) {

                    throw new RuntimeException(
                            "Barang dengan ID " +
                                    barangId +
                                    " tidak ditemukan"
                    );
                }


                if (jumlah <= 0) {

                    throw new RuntimeException(
                            "Jumlah barang harus lebih dari 0"
                    );
                }


                if (harga < 0) {

                    throw new RuntimeException(
                            "Harga barang tidak valid"
                    );
                }


                int stok =
                        barang.getStok() == null
                                ? 0
                                : barang.getStok();


                if (stok < jumlah) {

                    throw new RuntimeException(
                            "Stok " +
                                    barang.getNamaBarang() +
                                    " tidak mencukupi. " +
                                    "Stok tersedia: " +
                                    stok
                    );
                }
            }


            // ==========================================
            // 4. BUAT DETAIL DAN KURANGI STOK
            // ==========================================

            for (Map<String, Object> item : items) {

                Long barangId =
                        Long.valueOf(
                                item.get("barangId")
                                        .toString()
                        );

                Integer jumlah =
                        Integer.valueOf(
                                item.get("jumlah")
                                        .toString()
                        );

                Double harga =
                        Double.valueOf(
                                item.get("harga")
                                        .toString()
                        );


                Barang barang =
                        barangService.getBarangById(
                                barangId
                        );


                double subtotal =
                        harga * jumlah;


                DetailPenjualan detail =
                        new DetailPenjualan();


                detail.setBarang(barang);

                detail.setJumlah(jumlah);

                detail.setHarga(harga);

                detail.setSubtotal(subtotal);


                // Hubungkan detail dengan transaksi

                penjualan.addDetail(detail);


                // Tambahkan ke total

                total += subtotal;


                // Kurangi stok

                barangService.kurangiStok(
                        barangId,
                        jumlah
                );
            }


            // ==========================================
            // 5. SIMPAN TOTAL
            // ==========================================

            penjualan.setTotal(total);


            // ==========================================
            // 6. SIMPAN TRANSAKSI
            // ==========================================

            penjualanRepository.save(
                    penjualan
            );


            return "redirect:/penjualan";


        } catch (Exception e) {

            throw new RuntimeException(
                    "Gagal menyimpan transaksi: " +
                            e.getMessage(),
                    e
            );
        }
    }


    // ==========================================
    // DETAIL PENJUALAN
    // ==========================================

    @GetMapping("/detail/{id}")
    @Transactional(readOnly = true)
    public String detail(

            @PathVariable Long id,

            Model model) {


        Penjualan penjualan =
                penjualanRepository.findById(id)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Penjualan tidak ditemukan"
                                )
                        );


        model.addAttribute(
                "penjualan",
                penjualan
        );


        return "penjualan/detail";
    }


    // ==========================================
    // HAPUS TRANSAKSI
    // + KEMBALIKAN STOK
    // ==========================================

    @GetMapping("/hapus/{id}")
    @Transactional
    public String hapus(

            @PathVariable Long id) {


        Penjualan penjualan =
                penjualanRepository.findById(id)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Penjualan tidak ditemukan"
                                )
                        );


        // ==========================================
        // KEMBALIKAN STOK SEMUA BARANG
        // ==========================================

        for (DetailPenjualan detail :
                penjualan.getDetailPenjualan()) {


            Barang barang =
                    detail.getBarang();


            int stokSekarang =
                    barang.getStok() == null
                            ? 0
                            : barang.getStok();


            int jumlahDikembalikan =
                    detail.getJumlah() == null
                            ? 0
                            : detail.getJumlah();


            barang.setStok(
                    stokSekarang +
                            jumlahDikembalikan
            );


            barangService.saveBarang(
                    barang
            );
        }




        penjualanRepository.delete(
                penjualan
        );


        return "redirect:/penjualan";
    }

}