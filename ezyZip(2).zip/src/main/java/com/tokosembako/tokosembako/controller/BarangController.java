package com.tokosembako.tokosembako.controller;

import com.tokosembako.tokosembako.entity.Barang;
import com.tokosembako.tokosembako.service.BarangService;
import com.tokosembako.tokosembako.service.KategoriService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/barang")
public class BarangController {

    private final BarangService barangService;
    private final KategoriService kategoriService;

    public BarangController(BarangService barangService,
                            KategoriService kategoriService) {
        this.barangService = barangService;
        this.kategoriService = kategoriService;
    }

    @GetMapping
    public String index(Model model) {

        model.addAttribute("barangList",
                barangService.getAllBarang());

        return "barang";
    }

    @GetMapping("/tambah")
    public String tambah(Model model) {

        model.addAttribute("barang", new Barang());

        model.addAttribute("kategoriList",
                kategoriService.getAllKategori());

        return "barang-form";
    }

    @PostMapping("/simpan")
    public String simpan(@ModelAttribute Barang barang) {

        barangService.saveBarang(barang);

        return "redirect:/barang";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id,
                       Model model) {

        model.addAttribute("barang",
                barangService.getBarangById(id));

        model.addAttribute("kategoriList",
                kategoriService.getAllKategori());

        return "barang-form";
    }

    @GetMapping("/hapus/{id}")
    public String hapus(@PathVariable Long id) {

        barangService.deleteBarang(id);

        return "redirect:/barang";
    }
}