package com.tokosembako.tokosembako.controller;

import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;

import com.tokosembako.tokosembako.entity.Barang;
import com.tokosembako.tokosembako.entity.DetailPembelian;
import com.tokosembako.tokosembako.entity.Pembelian;
import com.tokosembako.tokosembako.entity.Supplier;
import com.tokosembako.tokosembako.repository.PembelianRepository;
import com.tokosembako.tokosembako.repository.SupplierRepository;
import com.tokosembako.tokosembako.service.BarangService;

import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/pembelian")
public class PembelianController {

    private final PembelianRepository pembelianRepository;
    private final SupplierRepository supplierRepository;
    private final BarangService barangService;
    private final ObjectMapper objectMapper;

    public PembelianController(
            PembelianRepository pembelianRepository,
            SupplierRepository supplierRepository,
            BarangService barangService,
            ObjectMapper objectMapper) {

        this.pembelianRepository = pembelianRepository;
        this.supplierRepository = supplierRepository;
        this.barangService = barangService;
        this.objectMapper = objectMapper;
    }

    // ==============================
    // DATA PEMBELIAN
    // ==============================

    @GetMapping
    public String index(Model model) {

        model.addAttribute(
                "pembelian",
                pembelianRepository.findAll()
        );

        return "pembelian/index";
    }


    // ==============================
    // FORM TAMBAH PEMBELIAN
    // ==============================

    @GetMapping("/tambah")
    public String tambah(Model model) {

        Pembelian pembelian = new Pembelian();

        pembelian.setTanggal(LocalDateTime.now());
        pembelian.setTotal(0.0);

        model.addAttribute("pembelian", pembelian);

        model.addAttribute(
                "supplierList",
                supplierRepository.findAll()
        );

        model.addAttribute(
                "barangList",
                barangService.getAllBarang()
        );

        return "pembelian/tambah";
    }


    // ==============================
    // SIMPAN PEMBELIAN
    // ==============================

    @PostMapping("/simpan")
    @Transactional
    public String simpan(
            @RequestParam("tanggal") String tanggal,
            @RequestParam("supplierId") Long supplierId,
            @RequestParam("items") String itemsJson) {

        try {

            List<Map<String, Object>> items =
                    objectMapper.readValue(
                            itemsJson,
                            new TypeReference<List<Map<String, Object>>>() {
                            }
                    );

            if (items == null || items.isEmpty()) {
                throw new RuntimeException(
                        "Belum ada barang dalam pembelian"
                );
            }

            Supplier supplier =
                    supplierRepository.findById(supplierId)
                            .orElseThrow(() ->
                                    new RuntimeException(
                                            "Supplier tidak ditemukan"
                                    )
                            );

            Pembelian pembelian = new Pembelian();

            if (tanggal != null && !tanggal.isEmpty()) {

                pembelian.setTanggal(
                        LocalDateTime.parse(tanggal)
                );

            } else {

                pembelian.setTanggal(
                        LocalDateTime.now()
                );
            }

            pembelian.setSupplier(supplier);

            double total = 0.0;


            // ==============================
            // VALIDASI SEMUA BARANG
            // ==============================

            for (Map<String, Object> item : items) {

                Long barangId =
                        Long.valueOf(
                                item.get("barangId").toString()
                        );

                Integer jumlah =
                        Integer.valueOf(
                                item.get("jumlah").toString()
                        );

                Double harga =
                        Double.valueOf(
                                item.get("harga").toString()
                        );

                Barang barang =
                        barangService.getBarangById(barangId);

                if (barang == null) {

                    throw new RuntimeException(
                            "Barang dengan ID " +
                                    barangId +
                                    " tidak ditemukan"
                    );
                }

                if (jumlah <= 0) {

                    throw new RuntimeException(
                            "Jumlah barang harus lebih dari 0"
                    );
                }

                if (harga < 0) {

                    throw new RuntimeException(
                            "Harga beli tidak valid"
                    );
                }
            }


            // ==============================
            // BUAT DETAIL + TAMBAH STOK
            // ==============================

            for (Map<String, Object> item : items) {

                Long barangId =
                        Long.valueOf(
                                item.get("barangId").toString()
                        );

                Integer jumlah =
                        Integer.valueOf(
                                item.get("jumlah").toString()
                        );

                Double harga =
                        Double.valueOf(
                                item.get("harga").toString()
                        );

                Barang barang =
                        barangService.getBarangById(barangId);

                double subtotal =
                        harga * jumlah;

                DetailPembelian detail =
                        new DetailPembelian();

                detail.setBarang(barang);
                detail.setJumlah(jumlah);
                detail.setHarga(harga);
                detail.setSubtotal(subtotal);

                pembelian.addDetail(detail);

                total += subtotal;

                // STOK BERTAMBAH
                barangService.tambahStok(
                        barangId,
                        jumlah
                );
            }

            pembelian.setTotal(total);

            pembelianRepository.save(pembelian);

            return "redirect:/pembelian";

        } catch (Exception e) {

            throw new RuntimeException(
                    "Gagal menyimpan pembelian: " +
                            e.getMessage(),
                    e
            );
        }
    }


    // ==============================
    // DETAIL PEMBELIAN
    // ==============================

    @GetMapping("/detail/{id}")
    @Transactional(readOnly = true)
    public String detail(
            @PathVariable Long id,
            Model model) {

        Pembelian pembelian =
                pembelianRepository.findById(id)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Pembelian tidak ditemukan"
                                )
                        );

        model.addAttribute(
                "pembelian",
                pembelian
        );

        return "pembelian/detail";
    }


    // ==============================
    // HAPUS PEMBELIAN
    // ==============================

    @GetMapping("/hapus/{id}")
    @Transactional
    public String hapus(
            @PathVariable Long id) {

        Pembelian pembelian =
                pembelianRepository.findById(id)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Pembelian tidak ditemukan"
                                )
                        );

        // KURANGI KEMBALI STOK
        for (
                DetailPembelian detail :
                pembelian.getDetailPembelian()
        ) {

            Barang barang =
                    detail.getBarang();

            int stokSekarang =
                    barang.getStok() == null
                            ? 0
                            : barang.getStok();

            int jumlahDikurangi =
                    detail.getJumlah() == null
                            ? 0
                            : detail.getJumlah();

            if (stokSekarang < jumlahDikurangi) {

                throw new RuntimeException(
                        "Stok " +
                                barang.getNamaBarang() +
                                " tidak mencukupi untuk membatalkan pembelian"
                );
            }

            barang.setStok(
                    stokSekarang -
                            jumlahDikurangi
            );

            barangService.saveBarang(barang);
        }

        pembelianRepository.delete(pembelian);

        return "redirect:/pembelian";
    }
}