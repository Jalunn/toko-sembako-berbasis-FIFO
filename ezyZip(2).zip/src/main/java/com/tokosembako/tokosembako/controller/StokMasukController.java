package com.tokosembako.tokosembako.controller;

import com.tokosembako.tokosembako.entity.StokMasuk;

import com.tokosembako.tokosembako.service.BarangService;
import com.tokosembako.tokosembako.service.StokMasukService;
import com.tokosembako.tokosembako.service.SupplierService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/stok-masuk")
public class StokMasukController {

    private final StokMasukService stokMasukService;
    private final BarangService barangService;
    private final SupplierService supplierService;

    public StokMasukController(
            StokMasukService stokMasukService,
            BarangService barangService,
            SupplierService supplierService) {

        this.stokMasukService = stokMasukService;
        this.barangService = barangService;
        this.supplierService = supplierService;
    }

    @GetMapping
    public String index(Model model) {

        model.addAttribute(
                "stokMasukList",
                stokMasukService.findAll()
        );

        return "stok-masuk/index";
    }

    @GetMapping("/tambah")
    public String tambah(Model model) {

        model.addAttribute(
                "stokMasuk",
                new StokMasuk()
        );

        model.addAttribute(
                "barangList",
                barangService.getAllBarang()
        );

        model.addAttribute(
                "supplierList",
                supplierService.getAllSupplier()
        );

        return "stok-masuk/tambah";
    }

    @PostMapping("/simpan")
    public String simpan(@ModelAttribute StokMasuk stokMasuk) {


        stokMasukService.save(stokMasuk);


        barangService.tambahStok(
                stokMasuk.getBarang().getId(),
                stokMasuk.getJumlah()
        );

        return "redirect:/stok-masuk";
    }

    @GetMapping("/hapus/{id}")
    public String hapus(@PathVariable Long id) {

        StokMasuk stokMasuk = stokMasukService.findById(id);

        if (stokMasuk != null) {


            barangService.kurangiStok(
                    stokMasuk.getBarang().getId(),
                    stokMasuk.getJumlah()
            );

            stokMasukService.delete(id);
        }

        return "redirect:/stok-masuk";
    }
}