package com.tokosembako.tokosembako.controller;

import com.tokosembako.tokosembako.entity.Supplier;
import com.tokosembako.tokosembako.service.SupplierService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/supplier")
public class SupplierController {

    private final SupplierService supplierService;

    public SupplierController(SupplierService supplierService) {
        this.supplierService = supplierService;
    }

    @GetMapping
    public String index(Model model) {

        model.addAttribute("supplierList",
                supplierService.getAllSupplier());

        return "supplier";
    }

    @GetMapping("/tambah")
    public String tambah(Model model) {

        model.addAttribute("supplier", new Supplier());

        return "supplier-form";
    }

    @PostMapping("/simpan")
    public String simpan(@ModelAttribute Supplier supplier) {

        supplierService.saveSupplier(supplier);

        return "redirect:/supplier";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id, Model model) {

        model.addAttribute("supplier",
                supplierService.getSupplierById(id));

        return "supplier-form";
    }

    @GetMapping("/hapus/{id}")
    public String hapus(@PathVariable Long id) {

        supplierService.deleteSupplier(id);

        return "redirect:/supplier";
    }
}