package com.tokosembako.tokosembako.controller;

import com.tokosembako.tokosembako.service.BarangService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PersediaanController {

    private final BarangService barangService;

    public PersediaanController(BarangService barangService) {
        this.barangService = barangService;
    }

    @GetMapping("/persediaan")
    public String persediaan(Model model) {

        model.addAttribute(
                "barangList",
                barangService.getAllBarang()
        );

        return "persediaan/index";
    }
}