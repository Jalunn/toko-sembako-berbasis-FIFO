package com.tokosembako.tokosembako.repository;

import com.tokosembako.tokosembako.entity.StokMasuk;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StokMasukRepository extends JpaRepository<StokMasuk, Long> {
}