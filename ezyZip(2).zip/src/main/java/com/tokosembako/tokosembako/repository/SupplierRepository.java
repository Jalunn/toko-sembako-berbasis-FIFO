package com.tokosembako.tokosembako.repository;

import com.tokosembako.tokosembako.entity.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SupplierRepository extends JpaRepository<Supplier, Long> {
}