package com.tokosembako.tokosembako.repository;

import com.tokosembako.tokosembako.entity.DetailPenjualan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetailPenjualanRepository
        extends JpaRepository<DetailPenjualan, Long> {
}