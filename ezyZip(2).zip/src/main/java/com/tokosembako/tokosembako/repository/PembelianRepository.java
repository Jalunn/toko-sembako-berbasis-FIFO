package com.tokosembako.tokosembako.repository;

import com.tokosembako.tokosembako.entity.Pembelian;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PembelianRepository extends JpaRepository<Pembelian, Long> {
}