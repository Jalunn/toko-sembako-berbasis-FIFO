package com.tokosembako.tokosembako.repository;

import com.tokosembako.tokosembako.entity.DetailPembelian;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetailPembelianRepository extends JpaRepository<DetailPembelian, Long> {
}