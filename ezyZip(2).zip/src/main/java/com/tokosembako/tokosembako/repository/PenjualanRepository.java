package com.tokosembako.tokosembako.repository;

import com.tokosembako.tokosembako.entity.Penjualan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PenjualanRepository extends JpaRepository<Penjualan, Long> {
}