package com.tokosembako.tokosembako.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "penjualan")
public class Penjualan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private LocalDateTime tanggal;

    @Column(nullable = false)
    private Double total;

    @OneToMany(
            mappedBy = "penjualan",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    private List<DetailPenjualan> detailPenjualan = new ArrayList<>();

    public Penjualan() {
    }

    public Penjualan(LocalDateTime tanggal, Double total) {
        this.tanggal = tanggal;
        this.total = total;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getTanggal() {
        return tanggal;
    }

    public void setTanggal(LocalDateTime tanggal) {
        this.tanggal = tanggal;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public List<DetailPenjualan> getDetailPenjualan() {
        return detailPenjualan;
    }

    public void setDetailPenjualan(List<DetailPenjualan> detailPenjualan) {
        this.detailPenjualan = detailPenjualan;
    }

    public void addDetail(DetailPenjualan detail) {
        detailPenjualan.add(detail);
        detail.setPenjualan(this);
    }

    public void removeDetail(DetailPenjualan detail) {
        detailPenjualan.remove(detail);
        detail.setPenjualan(null);
    }
}