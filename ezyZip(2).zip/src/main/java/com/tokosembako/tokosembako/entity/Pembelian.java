package com.tokosembako.tokosembako.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "pembelian")
public class Pembelian {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private LocalDateTime tanggal;

    @ManyToOne
    @JoinColumn(name = "supplier_id", nullable = false)
    private Supplier supplier;

    @Column(nullable = false)
    private Double total;

    @OneToMany(
            mappedBy = "pembelian",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    private List<DetailPembelian> detailPembelian = new ArrayList<>();

    public Pembelian() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getTanggal() {
        return tanggal;
    }

    public void setTanggal(LocalDateTime tanggal) {
        this.tanggal = tanggal;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public List<DetailPembelian> getDetailPembelian() {
        return detailPembelian;
    }

    public void setDetailPembelian(List<DetailPembelian> detailPembelian) {
        this.detailPembelian = detailPembelian;
    }

    public void addDetail(DetailPembelian detail) {
        detailPembelian.add(detail);
        detail.setPembelian(this);
    }

    public void removeDetail(DetailPembelian detail) {
        detailPembelian.remove(detail);
        detail.setPembelian(null);
    }
}